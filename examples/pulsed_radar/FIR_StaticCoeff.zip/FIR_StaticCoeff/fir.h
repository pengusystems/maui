#ifndef _H_FIR_H_
#define _H_FIR_H_

#include "/opt/Xilinx/Vivado/2018.2/include/gmp.h"
#include "/opt/Xilinx/Vivado/2018.2/include/mpfr.h"
#include <ap_fixed.h>
#include "hls_stream.h"
#include "ap_axi_sdata.h"
#include "stdint.h"
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

#define N	16
#define SAMPLES 1024
#define DATA_WIDTH_IN   18
#define DATA_WIDTH_OUT  48
#define ERROR_TOLERANCE 0.1
#define DB_FIXED_POINT
#ifdef DB_FIXED_POINT

// DATA TYPES
typedef ap_axis<64,1,1,1>           axi_stream_t;
typedef hls::stream<axi_stream_t>   axi_stream_hw_t;

typedef ap_fixed<18,2>	coef_t;
typedef ap_fixed<48,12>	out_data_t;
typedef ap_fixed<18,2>	inp_data_t;
typedef ap_fixed<48,12>	acc_t;

#else //FULLY ANSI C
typedef           int coef_t;
typedef long long int out_data_t;
typedef           int inp_data_t;
typedef long long int acc_t;

#endif

void top(hls::stream<axi_stream_t> &in_hw,hls::stream<axi_stream_t> &out_hw);
void top_wr(hls::stream<axi_stream_t> &in_hw,hls::stream<axi_stream_t> &out_hw,const int mode);
void fir_filter(hls::stream<inp_data_t> &in,hls::stream<out_data_t> &out,coef_t c[N]);
void fir_filter_wr(hls::stream<inp_data_t> &in,hls::stream<out_data_t> &out,coef_t c[N],const int mode);

template<typename axi_t, typename type_t, int SIZE>
void mem_read(
	hls::stream<axi_t>& in_hw,
	hls::stream<type_t>& in
)
{
#pragma HLS INTERFACE axis port=in_hw
#pragma HLS INTERFACE axis port=in
#pragma HLS STREAM variable=in_hw
#pragma HLS STREAM variable=in

	axi_t axi;

	loop_size: for (int i = 0; i < SIZE; i++)
	{
#pragma HLS LOOP_FLATTEN off
#pragma HLS PIPELINE II=1

		axi = in_hw.read();
		type_t tmp;
		tmp.range() = axi.data(DATA_WIDTH_IN-1,0);
		in.write(tmp);
	}
}

template<typename axi_t, typename type_t, int DATA_SIZE, int WR_SIZE>
void mem_read_wr(
		hls::stream<axi_t>& in_hw,
		hls::stream<type_t>& in,
		const int mode
)
{
#pragma HLS INTERFACE axis port=in_hw
#pragma HLS INTERFACE axis port=in

#pragma HLS STREAM variable=in_hw
#pragma HLS STREAM variable=in

	int eol=0;
	int sof=0;
	axi_t axi;

	if(mode == 0)
	{
		loop_data: for(int i = 0; i < DATA_SIZE; i++)
		{
#pragma HLS LOOP_FLATTEN off
#pragma HLS PIPELINE II=1

			axi = in_hw.read();
			type_t tmp;
			tmp.range() = axi.data(DATA_WIDTH_IN-1,0);
			in.write(tmp);
		}
	}
	else if(mode == 1)
	{
		loop_wr: for(int i = 0; i < WR_SIZE; i++)
		{
#pragma HLS LOOP_FLATTEN off
#pragma HLS PIPELINE II=1

			axi = in_hw.read();
			type_t tmp;
			tmp.range() = axi.data(DATA_WIDTH_IN-1,0);
			in.write(tmp);
		}
	}
}

template<typename axi_t, typename type_t, int SIZE>
void mem_write(
		hls::stream<type_t>& out,
		hls::stream<axi_t>& out_hw
)
{
#pragma HLS INTERFACE axis port=out_hw
#pragma HLS INTERFACE axis port=out
#pragma HLS STREAM variable=out_hw
#pragma HLS STREAM variable=out

	int eol=0;
	int sof=1;
	axi_t tmp;

	write_loop: for(int i=0;i<SIZE;i++) {
#pragma HLS PIPELINE II=1
#pragma HLS LOOP_FLATTEN off
		//set flags
		if(sof)
		{
			tmp.user = 1;
			sof = 0;
		}
		else
		{
			tmp.user = 0;
		}
		if(i==SIZE-1)
		{
			tmp.last = 1;
		}
		else
		{
			tmp.last = 0;
		}

		type_t val = out.read();
		tmp.data.range(64-1,DATA_WIDTH_OUT) = 0;
		tmp.data.range(DATA_WIDTH_OUT-1,0) = val.range();
		tmp.keep = -1;
		out_hw.write(tmp);
	}
}

template<typename axi_t, typename type_t, int SIZE>
void mem_write_wr(
		hls::stream<type_t>& out,
		hls::stream<axi_t>& out_hw,
		const int mode
)
{
	#pragma HLS INTERFACE axis port=out_hw
	#pragma HLS INTERFACE axis port=out
	#pragma HLS STREAM variable=out_hw
	#pragma HLS STREAM variable=out

	int eol=0;
	int sof=1;
	axi_t tmp;

	if(mode == 0)
	{
		write_loop: for(int i=0;i<SIZE;i++) {
#pragma HLS PIPELINE II=1
#pragma HLS LOOP_FLATTEN off

			if(sof)
			{
				tmp.user = 1;
				sof = 0;
			}
			else
			{
				tmp.user = 0;
			}
			if(i==SIZE-1)
			{
				tmp.last = 1;
			}
			else
			{
				tmp.last = 0;
			}

			type_t val = out.read();
			tmp.data.range(64-1,DATA_WIDTH_OUT) = 0;
			tmp.data.range(DATA_WIDTH_OUT-1,0) = val.range();
			tmp.keep = -1;
			out_hw.write(tmp);
		}
	}
}

template<int SIZE,int DATA_WIDTH,typename AXI_T,typename T>
void getArray2Stream_axi(
		T in[SIZE],
		hls::stream<AXI_T> &out
)
{
	AXI_T axi;
	int cnt = 0;

	for(int k=0; k<SIZE; k++)
	{
		axi.data.range(64-1,DATA_WIDTH) = 0;
		axi.data.range(DATA_WIDTH-1,0) = in[k].range();
		axi.user = (cnt==0)  ? 1 : 0;
		axi.last = (cnt==SIZE)   ? 1 : 0;
		axi.keep = -1;
		axi.id   = 0;
		axi.dest = 0;
		out << axi;
		cnt++;
	}
}

template<typename AXI_T, typename T>
int checkStreamEqual_axi(
		hls::stream<AXI_T> &test,
		hls::stream<AXI_T> &valid,
		bool print_out=false
)
{
	int err = 0;
	while(!valid.empty())
	{
		if(test.empty())
		{
			printf("ERROR: empty early\n");
			return 1;
		}
		AXI_T axi_tmp = test.read();
		AXI_T axi_tmp_valid = valid.read();

		T tmp;
		T tmp_valid;
		tmp.range() = axi_tmp.data(DATA_WIDTH_OUT-1,0);
		tmp_valid.range() = axi_tmp_valid.data(DATA_WIDTH_OUT-1,0);

		if(print_out)
			printf("%f,%f\n", tmp.to_float(), tmp_valid.to_float());
		if(
				(tmp.to_float() > tmp_valid.to_float()+ERROR_TOLERANCE) ||
				(tmp.to_float() < tmp_valid.to_float()-ERROR_TOLERANCE)
		)
		{
			printf("ERROR: wrong value\n");
			err++;
			return err;
		}
	}
	if(!test.empty())
	{
		printf("ERROR: still data in stream\n");
		err++;
		return err;
	}
	return err;
}

#endif
