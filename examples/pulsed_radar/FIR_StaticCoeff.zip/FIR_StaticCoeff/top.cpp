#include "fir.h"

coef_t taps[N] = {
#include "./data/fir_coeff.dat"
};

void top(
		hls::stream<axi_stream_t> &in_hw,
		hls::stream<axi_stream_t> &out_hw
)
{
#pragma HLS INTERFACE s_axilite port=return bundle=ctrl
#pragma HLS INTERFACE axis port=in_hw
#pragma HLS INTERFACE axis port=out_hw
#pragma HLS STREAM variable=in_hw
#pragma HLS STREAM variable=out_hw

#pragma HLS RESOURCE variable=taps core=RAM_2P_BRAM

hls::stream<inp_data_t> in("fir_in");
hls::stream<out_data_t> out("fir_out");

#pragma HLS STREAM variable=in depth=1+1
#pragma HLS STREAM variable=out depth=1+1

#pragma HLS DATAFLOW

	// Read from the input AXI-Stream interface
	mem_read<axi_stream_t,inp_data_t,SAMPLES>(in_hw,in);
	// FIR filter
	fir_filter(in,out,taps);
	// Write to the output AXI-Stream interface
	mem_write<axi_stream_t,out_data_t,SAMPLES>(out,out_hw);
}
